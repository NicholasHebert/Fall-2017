/*
Hello World example to serving string to client
*/
//To test use browser to view http://localhost:3000
//Cntl+C to stop server

var http = require('http');
var counter = 1000; 

http.createServer(function (request,response){
   //respond to client
   response.writeHead(200, {'Content-Type': 'text/plain'});
   response.write('Hello\n');
   response.write('World\n');
   //end HTTP response and provide final data to send
   response.end("["+ counter++ + "]\n");
}).listen(3000);
console.log('Server Running at http://127.0.0.1:3000  CNTL-C to quit');
console.log('To test with browser visit: http://localhost:3000');