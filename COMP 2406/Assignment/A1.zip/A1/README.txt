Assignment 1 - COMP 2406
Nicholas Hebert (100954895)

Chord reader:

To start the server run the command, in a terminal or command prompt, "node app.js" from the directory it was saved in.

To stop the server use "CTRL+C" from the same terminal or command prompt.

To access the webpage, using any browser (Chrome tested), visit "localhost:3000/index.html".

This webpage is designed to display lyrics and chords in a manner that makes it easier for players to read.
Each word can be moved around by clicking and dragging.
-The search button searches for songs in the song folder.
-The save button saves the current ordering of the words to the server(this always overwrites the file opened).
-The Sort button sorts the current ordering of the words back to it's original layout.


Code was compiled on:   Mac OSX - 10.12.6
                        Node - v6.11.0

Code was tested on:     Chrome - Version 61.0.3163.100 (Official Build) (x64)
